

# AURUM Estates — Luxury Real Estate Website

A stunning, dark-themed luxury property showcase website with real photography and immersive 360° virtual tours.

---

## 🏠 Core Features

### 1. **Hero Section**
- Elegant full-screen landing with animated gold accents
- Brand identity: "AURUM" with luxury typography (Playfair Display + Raleway fonts)
- Smooth scroll-down indicator
- Dark theme with gold accent colors (#c9a84c)

### 2. **Property Listings Grid**
- 6 luxury estate cards featuring **real stock photography** from Unsplash/Pexels
- Each card shows:
  - High-quality property image
  - Property name, location, and price
  - Key specs (bedrooms, baths, square footage)
  - "For Sale" or "Sold" status badges
- Hover effects reveal action buttons for 360° tour and site map

### 3. **360° Panorama Virtual Tour Viewer**
- Immersive room-by-room virtual tours using **real 360° panoramic images**
- Three.js-powered spherical projection viewer
- Drag to look around, scroll to zoom
- Room selector tabs (Living Room, Master Suite, Kitchen, etc.)
- Mobile touch controls supported

### 4. **Interactive Site Maps**
- SVG-based property layout diagrams
- Shows: Main residence, garden, pool, driveway, garage
- Legend with color-coded zones

### 5. **Estate Finder Q&A**
- Guided questionnaire sidebar
- Questions about budget, property size, purpose, and preferred setting
- AI-matched property recommendations based on answers
- Progress indicator dots

---

## 🎨 Design & Style

- **Color Palette**: Deep black (#0a0a0a), gold accents (#c9a84c), cream text
- **Typography**: Playfair Display (serif headings), Raleway (body)
- **Effects**: Subtle grain texture, smooth animations, backdrop blur
- **Responsive**: Mobile-first design with hamburger navigation

---

## 📷 Image Strategy

- **Property Cards**: High-quality luxury home photos from Unsplash/Pexels
- **360° Tours**: Free equirectangular panoramas from Freepik/Vecteezy for room views
- All images will be royalty-free and properly attributed

---

## 🔧 Technical Implementation

- React + TypeScript + Tailwind CSS
- Three.js for 360° panorama rendering
- Smooth CSS animations and transitions
- Fully client-side (no backend needed initially)

